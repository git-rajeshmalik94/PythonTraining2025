import math

def factorial(n):
    if n < 0:
        raise ValueError("Negative values are not allowed.")
    return math.factorial(n)

def is_prime(n):
    if n <= 1:
        return False
    for i in range(2, int(math.sqrt(n)) + 1):
        if n % i == 0:
            return False
    return True

def area_of_circle(radius):
    if radius <= 0:
        raise ValueError("Radius must be greater than zero.")
    return math.pi * radius ** 2
