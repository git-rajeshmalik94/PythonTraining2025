import pytest
from math import pi
from Calculation import factorial, is_prime, area_of_circle

# Factorial tests
def test_factorial_4():
    assert factorial(4) == 24

def test_factorial_0():
    assert factorial(0) == 1

# Prime tests
def test_is_prime_31():
    assert is_prime(31)

def test_is_prime_17():
    assert is_prime(17)

def test_is_prime_0():
    assert not is_prime(0)

# Area of circle tests
def test_area_of_circle_4():
    assert area_of_circle(4) == pytest.approx(pi * 16)

def test_area_of_circle_zero():
    with pytest.raises(ValueError):
        area_of_circle(0)