import unittest
from math import pi
from Calculation import factorial, is_prime, area_of_circle

class TestMathFunctions(unittest.TestCase):
    # Factorial tests
    def test_factorial_4(self):
        self.assertEqual(factorial(4), 24)

    def test_factorial_0(self):
        self.assertEqual(factorial(0), 1)

    # Prime tests
    def test_is_prime_31(self):
        self.assertTrue(is_prime(31))

    def test_is_prime_17(self):
        self.assertTrue(is_prime(17))

    def test_is_prime_0(self):
        self.assertFalse(is_prime(0))

    # Area of circle tests
    def test_area_of_circle_4(self):
        self.assertAlmostEqual(area_of_circle(4), pi * 16)

    def test_area_of_circle_zero(self):
        with self.assertRaises(ValueError):
            area_of_circle(0)

if __name__ == '__main__':
    unittest.main()